import React from 'react';
import {Composition} from 'remotion';
import {Video} from './video';
export const Root: React.FC = () => <Composition id="NuclearSubmarine" component={Video} durationInFrames={824} fps={30} width={1080} height={1920}/>;
