import React from 'react';
import {AbsoluteFill, Audio, Sequence, useCurrentFrame, useVideoConfig, interpolate, staticFile, Easing} from 'remotion';

const C = {navy:'#061725', deep:'#03101d', blue:'#36c9ed', cyan:'#8cecff', steel:'#718493', light:'#c8d5dc', orange:'#ff7a28', gold:'#ffc15c', green:'#76e6b5'};
const clamp={extrapolateLeft:'clamp' as const,extrapolateRight:'clamp' as const};
const fade=(f:number,a:number,b:number)=>interpolate(f,[a,a+12,b-12,b],[0,1,1,0],clamp);
const glow=(color:string,blur=22)=>`drop-shadow(0 0 ${blur}px ${color})`;

const Ocean:React.FC<{frame:number}> = ({frame}) => <>
 <defs><linearGradient id="ocean" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#123b54"/><stop offset=".45" stopColor="#08253a"/><stop offset="1" stopColor="#020b15"/></linearGradient><radialGradient id="vignette"><stop stopColor="#16405a" stopOpacity=".1"/><stop offset="1" stopColor="#000814" stopOpacity=".8"/></radialGradient><linearGradient id="metal" x1="0" y1="0" x2="0" y2="1"><stop stopColor="#d0dce1"/><stop offset=".22" stopColor="#647887"/><stop offset=".55" stopColor="#263d4d"/><stop offset=".82" stopColor="#8295a0"/><stop offset="1" stopColor="#1a2b38"/></linearGradient></defs>
 <rect width="1080" height="1920" fill="url(#ocean)"/><rect width="1080" height="1920" fill="url(#vignette)"/>
 {Array.from({length:28},(_,i)=><circle key={i} cx={(i*173+frame*(i%3+1)*.35)%1120-20} cy={(i*271+frame*(i%4+1)*.7)%1960-20} r={i%4===0?3:1.5} fill="#a6eaff" opacity={.13+(i%4)*.04}/>)}
 <path d={`M0 ${340+Math.sin(frame/34)*12} Q260 ${290+Math.sin(frame/34)*12} 540 340 T1080 330`} stroke="#8bdcf0" strokeWidth="3" opacity=".08" fill="none"/>
 </>;

const Submarine:React.FC<{x?:number;y?:number;scale?:number;cut?:boolean;frame:number}> = ({x=0,y=0,scale=1,cut=false,frame}) => <g transform={`translate(${x} ${y}) scale(${scale})`}>
 <path d="M90 250 Q120 170 250 150 L710 150 Q790 150 855 205 L950 245 L855 285 Q790 340 710 340 L250 340 Q120 320 90 250Z" fill="url(#metal)" stroke="#c3d4dd" strokeWidth="4"/>
 <path d="M455 150 L455 340 M480 150 L480 340" stroke="#1b3444" strokeWidth="7" opacity=".8"/>
 <path d="M470 150 L500 82 L640 82 L675 150Z" fill="#526d7d" stroke="#c5d4dc" strokeWidth="4"/><path d="M535 82 L535 40 L590 40 L590 82" fill="#78909d" stroke="#d3e0e5" strokeWidth="3"/>
 <path d="M940 245 L1000 190 L1000 300Z" fill="#647e8c" stroke="#c3d4dd" strokeWidth="4"/>
 <path d="M130 245 L45 190 L45 300Z" fill="#536d7b" stroke="#b8c9d1" strokeWidth="4"/>
 {Array.from({length:8},(_,i)=><circle key={i} cx={220+i*78} cy="246" r="7" fill="#172d3a" stroke="#b2c4ce" strokeWidth="2"/>)}
 <path d="M455 150 Q530 160 680 155 L680 335 Q530 330 455 340Z" fill={cut?'#071b29':'#243d4d'} opacity={cut?'.9':'.2'} stroke="#a8bdc9" strokeWidth="2"/>
 {cut&&<g><rect x="500" y="190" width="120" height="110" rx="18" fill="#425a68" stroke="#d2e0e6" strokeWidth="4"/><rect x="525" y="210" width="70" height="70" rx="8" fill="#ff7a28" opacity=".85" style={{filter:glow('#ff6a21',25)}}/>{Array.from({length:5},(_,i)=><path key={i} d={`M${535+i*13} 215 v60`} stroke="#ffe1a7" strokeWidth="4" opacity=".8"/>)}<path d="M640 215 h85 v95 h-85" fill="#516c7b" stroke="#b8cbd5" strokeWidth="4"/><g transform={`rotate(${frame*9} 680 260)`}>{Array.from({length:7},(_,i)=><path key={i} d="M680 260 Q720 220 735 250 Q710 270 680 260" fill="#9ab0bc" stroke="#dce8ed" strokeWidth="2" transform={`rotate(${i*51} 680 260)`}/>)}</g></g>}
 </g>;

const Header:React.FC<{title:string;sub:string;frame:number}> = ({title,sub,frame}) => <div style={{position:'absolute',top:125,left:70,right:70,opacity:interpolate(frame,[0,15],[0,1],clamp)}}><div style={{fontFamily:'Arial',fontSize:25,letterSpacing:7,color:C.cyan,fontWeight:800}}>MACHINE EXPLAINED</div><div style={{fontFamily:'Arial',fontSize:64,lineHeight:1.05,fontWeight:900,color:'#fff',marginTop:18,textShadow:'0 5px 24px #000'}}>{title}</div><div style={{fontFamily:'Arial',fontSize:27,color:'#b6d4e1',marginTop:18,letterSpacing:1}}>{sub}</div></div>;

const Scene:React.FC<{start:number;end:number;title:string;sub:string;kind:number}> = ({start,end,title,sub,kind}) => {
 const f=useCurrentFrame(); const globalF=f+start; const local=f; const op=fade(globalF,start,end); const pulse=1+Math.sin(local/8)*.035;
 return <AbsoluteFill style={{opacity:op}}><svg width="1080" height="1920" viewBox="0 0 1080 1920" style={{position:'absolute'}}><Ocean frame={f}/>
 {kind===0&&<g transform={`translate(${Math.sin(local/18)*18} ${Math.sin(local/20)*8})`}><Submarine x={-5+local*1.4} y={610} scale={1.08} frame={f}/><path d="M90 1080 Q530 960 990 1080" stroke={C.cyan} strokeWidth="3" opacity=".2" fill="none"/></g>}
 {kind===1&&<g transform={`translate(0 ${Math.sin(local/12)*8})`}><Submarine x={-40} y={650} scale={1.12} cut frame={f}/><circle cx="580" cy="900" r={170*pulse} fill="none" stroke={C.orange} strokeWidth="5" opacity=".65" style={{filter:glow(C.orange,18)}}/><circle cx="580" cy="900" r="215" fill="none" stroke={C.gold} strokeWidth="2" opacity=".3"/></g>}
 {kind===2&&<g><Submarine x={-20} y={690} scale={1.13} cut frame={f}/>{Array.from({length:5},(_,i)=><path key={i} d={`M${590+i*20} 1010 Q${690+i*20} ${850-i*14} ${800+i*20} 1020`} stroke={i%2?C.orange:C.cyan} strokeWidth="8" fill="none" opacity=".7" style={{filter:glow(i%2?C.orange:C.cyan,12)}}/>)}<g transform={`rotate(${local*8} 820 1000)`}>{Array.from({length:8},(_,i)=><path key={i} d="M820 1000 L820 900 Q850 940 820 1000" fill="#a9bdc8" stroke="#e1edf1" strokeWidth="3" transform={`rotate(${i*45} 820 1000)`}/>)}</g></g>}
 {kind===3&&<g><Submarine x={-15} y={700} scale={1.1} frame={f}/><rect x="230" y="890" width="620" height="210" rx="85" fill="#071b2a" stroke={C.cyan} strokeWidth="4" opacity=".9"/><path d={`M270 990 Q430 ${930+Math.sin(local/9)*20} 570 990 T810 990`} stroke="#39c9ec" strokeWidth="30" fill="none" opacity=".65" style={{filter:glow(C.cyan,20)}}/><path d="M270 990 Q430 930 570 990 T810 990" stroke="#d2f8ff" strokeWidth="5" fill="none"/></g>}
 {kind===4&&<g><Submarine x={-30} y={700} scale={1.1} frame={f}/>{Array.from({length:5},(_,i)=><ellipse key={i} cx="550" cy="930" rx={90+i*80+Math.sin(local/10)*8} ry={35+i*23} fill="none" stroke={C.green} strokeWidth="4" opacity={.7-i*.1} style={{filter:glow(C.green,10)}}/>)}<path d="M770 980 l110 -70 65 80 -120 55Z" fill="#526d7b" stroke="#c4d5dd" strokeWidth="4"/></g>}
 {kind===5&&<g><Submarine x={-10+local*.5} y={720} scale={1.12} cut frame={f}/><circle cx="600" cy="960" r="260" fill="none" stroke={C.orange} strokeWidth="3" opacity=".25"/><path d="M100 1180 Q540 1080 980 1180" stroke="#8edcf0" strokeWidth="2" opacity=".15" fill="none"/></g>}
 </svg>
 <Header title={title} sub={sub} frame={globalF}/>
 <div style={{position:'absolute',bottom:210,left:72,right:72,display:'flex',alignItems:'center',gap:18}}><div style={{height:5,background:'#ffffff35',flex:1,borderRadius:5,overflow:'hidden'}}><div style={{height:'100%',width:`${Math.max(0,Math.min(100,(globalF/824)*100))}%`,background:C.cyan}}/></div><div style={{fontFamily:'Arial',fontSize:20,color:'#b8d8e5',letterSpacing:2}}>DEEP OCEAN</div></div>
 </AbsoluteFill>;
};

export const Video:React.FC=()=>{
 const f=useCurrentFrame(); const {fps}=useVideoConfig();
 return <AbsoluteFill style={{background:C.deep}}>
  <Sequence from={0} durationInFrames={108}><Scene start={0} end={108} title="BUILT TO DISAPPEAR" sub="Months beneath the ocean surface" kind={0}/></Sequence>
  <Sequence from={108} durationInFrames={108}><Scene start={108} end={216} title="A NUCLEAR HEART" sub="A reactor creates continuous heat" kind={1}/></Sequence>
  <Sequence from={216} durationInFrames={228}><Scene start={216} end={444} title="POWER FROM STEAM" sub="Heat → steam → turbine rotation" kind={2}/></Sequence>
  <Sequence from={444} durationInFrames={141}><Scene start={444} end={585} title="SINK OR RISE" sub="Ballast tanks control buoyancy" kind={3}/></Sequence>
  <Sequence from={585} durationInFrames={111}><Scene start={585} end={696} title="HEARING IN THE DARK" sub="Sonar listens for returning echoes" kind={4}/></Sequence>
  <Sequence from={696} durationInFrames={128}><Scene start={696} end={824} title="POWER BENEATH THE WAVES" sub="An underwater machine built for endurance" kind={5}/></Sequence>
  <Audio src={staticFile('audio/voiceover.m4a')} volume={1}/>
  <AbsoluteFill style={{pointerEvents:'none',background:'linear-gradient(180deg,rgba(0,0,0,.28),transparent 28%,transparent 72%,rgba(0,0,0,.35))'}}/>
 </AbsoluteFill>;
};
