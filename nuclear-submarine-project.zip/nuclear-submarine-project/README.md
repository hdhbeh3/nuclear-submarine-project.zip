# Nuclear Submarine — Remotion Short

A 9:16, 1080×1920, 30 FPS Remotion project packaged with the supplied voiceover.

## Voiceover
- File: `public/audio/voiceover.m4a`
- Measured duration: 27.455 seconds
- Composition: 824 frames (27.467 seconds at 30 FPS)
- The final composition uses the uploaded recording directly as the narration track.

## Render on GitHub Actions (Android-friendly)
1. Extract this ZIP.
2. Upload the extracted project contents to a new GitHub repository (keep the `.github` folder).
3. Open the repository's **Actions** tab.
4. Select **Render Nuclear Submarine Short**.
5. Tap **Run workflow** and wait for the green check.
6. Open the completed run, scroll to **Artifacts**, and download `nuclear-submarine-video`.
7. Extract the artifact to get `nuclear-submarine.mp4`.

## Local render
Requires Node.js 20+ and internet access for npm dependencies:

```bash
npm install
npm run render
```

## Project notes
- Six animated educational scenes: submarine exterior, reactor, steam/turbine, ballast tanks, sonar, finale.
- Procedural SVG-based layered visuals and animated mechanical details; this is a stylized 2.5D/technical motion-graphics treatment, not a photorealistic full 3D simulation.
- Scene boundaries are an initial edit matched to the 27.455-second audio duration. Fine-grained word-level synchronization should be adjusted after reviewing the rendered video against the recording.
- No captions or automatic subtitles are added.
